import matplotlib.pyplot as plt
import numpy as np

def image_check(gen_fake):
    img = gen_fake.data.numpy()
    fig, axs = plt.subplots(3,3, figsize=(10,10))
    axs = axs.ravel()
    for i in range(9):
        t_img = np.moveaxis(img[i], 0, -1)
        t_img = (((t_img - t_img.min()) * 255) / (t_img.max() - t_img.min())).astype(np.uint8)
        axs[i].imshow(t_img, cmap=None, aspect="equal")
    plt.show()