import torch.nn as nn
from collections import OrderedDict

class Generator(nn.Module):
    def __init__(self, ngf):
        super(Generator,self).__init__()
        self.layer1 = nn.Sequential(
             nn.ConvTranspose2d(100,ngf*8,4,1,0,bias=False),
             nn.BatchNorm2d(ngf*8),
             nn.ReLU(True),
        )
        self.layer2 = nn.Sequential(OrderedDict([
                        ('conv1', nn.ConvTranspose2d(ngf*8,ngf*4,4,2,1,bias=False)),
                        ('bn1', nn.BatchNorm2d(ngf*4)),
                        ('relu1', nn.LeakyReLU()),
                        ('conv2', nn.ConvTranspose2d(ngf*4,ngf*2,4,2,1, bias=False)),
                        ('bn2', nn.BatchNorm2d(ngf*2)),
                        ('relu2', nn.LeakyReLU()),
            ]))
        self.layer3 = nn.Sequential(OrderedDict([
                        ('conv3',nn.ConvTranspose2d(ngf*2,ngf,4,2,1, bias=False)),
                        ('bn3',nn.BatchNorm2d(ngf)),
                        ('relu3',nn.LeakyReLU()),
                        ('conv4',nn.ConvTranspose2d(ngf,3,4,2,1,bias=False)),
                        ('relu4',nn.Tanh())
            ]))

    def forward(self,z):
        out = self.layer1(z)
        # out = out.view(batch_size//num_gpus,256,7,7)
        out = self.layer2(out)
        out = self.layer3(out)
        return out


class Discriminator(nn.Module):
    def __init__(self, ndf):
        super(Discriminator,self).__init__()
        self.layer1 = nn.Sequential(OrderedDict([
                        ('conv1',nn.Conv2d(3,ndf,4,2,1,bias=False)),   # batch x 16 x 28 x 28
                        #('bn1',nn.BatchNorm2d(8)),
                        ('relu1',nn.LeakyReLU(0.2, inplace=True)),
                        ('conv2',nn.Conv2d(ndf,ndf*2,4,2,1,bias=False)),  # batch x 32 x 28 x 28
                        ('bn2',nn.BatchNorm2d(ndf*2)),
                        ('relu2',nn.LeakyReLU(0.2, inplace=True))
        ]))
        self.layer2 = nn.Sequential(OrderedDict([
                        ('conv3',nn.Conv2d(ndf*2,ndf*4,4,2,1, bias=False)),  # batch x 64 x 14 x 14
                        ('bn3',nn.BatchNorm2d(ndf*4)),
                        ('relu3',nn.LeakyReLU(0.2, inplace=True)),
                        # ('max2',nn.MaxPool2d(2,2)),
                        ('conv4',nn.Conv2d(ndf*4, ndf*8, 4, 2, 1, bias=False)),  # batch x 128 x 7 x 7
                        ('bn4',nn.BatchNorm2d(ndf*8)),
                        ('relu4',nn.LeakyReLU(0.2, inplace=True))
        ]))
        self.fc = nn.Sequential(
                        nn.Conv2d(ndf*8,1,4,1,0,bias=False),
                        nn.Sigmoid()
        )

    def forward(self,x):
        out = self.layer1(x)
        out = self.layer2(out)
        # out = out.view(batch_size//num_gpus, -1)
        out = self.fc(out)

        return out.view(-1,1).squeeze(1)
        # return out

#check model layers
def check_model_layers():
    generator = nn.DataParallel(Generator()).cuda()
    discriminator = nn.DataParallel(Discriminator()).cuda()

    # 파라미터 확인하기 using class.state_dict().keys

    gen_params = generator.state_dict().keys()
    dis_params = discriminator.state_dict().keys()

    for i in dis_params:
        print(i)