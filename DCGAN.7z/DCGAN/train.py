import torch.nn as nn
import torch
from torch.autograd import Variable
import torchvision.utils as vutils
import os
import draw_image
import model
import get_data

data_dir = "../data/celeba/"
save_path = "./data/result"
model_check = False

#parameter
ngf = 64
ndf = 64
epoch = 10
batch_size = 64
learning_rate = 0.0002
num_gpus = 1
image_size= 64

#Get data
train_loader = get_data.get_data(data_dir,image_size,batch_size)

#Get model
generator = nn.DataParallel(model.Generator(ngf)).cuda()
discriminator = nn.DataParallel(model.Discriminator(ndf)).cuda()

#model check
if model_check:
    model.check_model_layers()

#Loss function & Optimizer
loss_func = nn.BCELoss()
gen_optim = torch.optim.Adam(generator.parameters(), lr= 5*learning_rate,betas=(0.5,0.999))
dis_optim = torch.optim.Adam(discriminator.parameters(), lr=learning_rate,betas=(0.5,0.999))

#fixed_z
fixed_z = Variable(torch.Tensor(batch_size,100,1,1).normal_(0,1)).cuda() #noise

#Train
real_label = 1
fake_label = 0
for i in range(epoch):
    gen_loss_list = []
    dis_loss_list = []
    for j, data in enumerate(train_loader):
        if j % 20 == 0:
            fake = generator(fixed_z)
            vutils.save_image(fake.data, os.path.join(save_path, "fake_samples_epoch_{}.png".format(i)), normalize=True)
        # discriminator update: maximize log(D(x)) + log(1-D(z))
        if data[0].size(0) != batch_size:
            print("skip")
            continue

        else:
            dis_optim.zero_grad()
            image = data[0].cuda()
            b_size = image.size(0)
            label = torch.full((b_size,), real_label).cuda()
            dis_real = discriminator.forward(image).view(-1, 1)
            dis_real_error = torch.sum(loss_func(dis_real, label))  # 진짜를 진짜와 비교했을 때 에러값
            dis_real_error.backward()
            dis_optim.step()

            z = Variable(torch.Tensor(batch_size, 100, 1, 1).normal_(0, 1)).cuda()  # noise
            gen_fake = generator.forward(z)  # generator로 생성한 fake image
            label.fill_(fake_label)
            dis_fake = discriminator.forward(gen_fake.detach()).view(-1, 1)  # fake를 discriminate
            dis_fake_error = torch.sum(loss_func(dis_fake, label))  # fake를 fake라고 한 error
            dis_fake_error.backward()

            # 최종 loss 값
            dis_loss = dis_real_error + dis_fake_error  # 진짜를 진짜로, 가짜를 가짜로 한 거. loss가 적어야 discriminator가 제대로 작동하지 않는 거
            dis_optim.step()

            # generator update 하기
            gen_optim.zero_grad()
            label.fill_(real_label)
            gen_dis_fake = discriminator.forward(gen_fake).view(-1, 1)
            gen_loss = torch.sum(loss_func(gen_dis_fake, label))  # 가짜를 진짜라고 한 에러. 낮아야 generator가 제대로 작동한 거
            gen_loss.backward()
            gen_optim.step()

            # model save
            if j % 100 == 0:
                gen_loss_list.append(gen_loss.data)
                dis_loss_list.append(dis_loss.data)
                print("{}th iteration gen_loss: {} dis_loss: {}".format(i, gen_loss.data, dis_loss.data))

    # draw_image.image_check(gen_fake.cpu())