def image(img_dir):
