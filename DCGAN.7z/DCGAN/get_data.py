import torchvision.datasets as dset
import torchvision.transforms as transforms
import torch

def get_data(directory, image_size=64, batch_size=64):
    dataset = dset.ImageFolder(root=directory,
                               transform=transforms.Compose([
                                   transforms.Resize(image_size),
                                   transforms.CenterCrop(image_size),
                                   transforms.ToTensor(),
                                   transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
                               ]))

    train_loader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,
                                             shuffle=True, num_workers=0)
    return train_loader